#pragma once

enum class GameMode {
    Training,
    WizardsDuel,
    ElementsDuel,
    Tournament
};